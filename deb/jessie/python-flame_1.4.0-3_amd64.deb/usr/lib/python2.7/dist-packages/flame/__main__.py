from __future__ import print_function
from . import version, cversion
print("This is FLAME\n Python API version:", version,"\n C++ API version:", cversion)
